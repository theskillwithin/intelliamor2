<?php
/**
* Copyright © Pulse Storm LLC 2016
* All rights reserved
*/
namespace Austinpeterson\Commercebug\Model;
use Magento\Framework\DataObject as Object;

class ViewVars extends Object
{
}